//
//  GlobalConstants.swift
//  HooqDemo
//
//  Created by Kajal on 1/3/2019.
//  Copyright © 2018 Kajal. All rights reserved.
//

import Foundation

struct GlobalConstants {
    
    static let AppName = "HOOQ"
    static let homeImageURL = "https://image.tmdb.org/t/p/w154"
    static let detailImageURL = "https://image.tmdb.org/t/p/original"
    static let LoadingViewAnimation = 0.35
    static let LoadingViewDelay = 0.35
    static let SplashLoadingAnimation = 1.5
    static let SplashLoadingDelay = 1.3
    static let Okay = "Okay!"
    static let ApiFailure = "Oops! Something went wrong!"
    static let noImage = "noImageAvailable"
}



